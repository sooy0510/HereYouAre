from django.apps import AppConfig


class WebserverConfig(AppConfig):
    name = 'webserver'
