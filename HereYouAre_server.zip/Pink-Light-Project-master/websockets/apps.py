from django.apps import AppConfig


class WebsocketsConfig(AppConfig):
    name = 'websockets'
